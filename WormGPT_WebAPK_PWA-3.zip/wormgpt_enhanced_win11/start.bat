@echo off
setlocal enabledelayedexpansion
title WormGPT Enhanced

echo.
echo  Starting WormGPT Enhanced...
echo.

:: Check if Ollama is already running
tasklist /FI "IMAGENAME eq ollama.exe" 2>nul | find /I "ollama.exe" >nul
if %errorlevel% neq 0 (
    echo  [INFO] Starting Ollama service...
    start /B "" ollama serve >nul 2>&1
    timeout /t 3 /nobreak >nul
    echo  [OK] Ollama started
) else (
    echo  [OK] Ollama already running
)

:: Start the backend server
echo  [INFO] Starting backend server...
cd /d "%~dp0server"
start /B "" node index.js
timeout /t 2 /nobreak >nul

echo.
echo  ===========================================
echo   WormGPT Enhanced is Running!
echo  ===========================================
echo.
echo   Browser:  http://localhost:3001
echo   Password: Realnojokepplwazy1234
echo.
echo   Opening browser...
start http://localhost:3001

echo.
echo   Press Ctrl+C or close this window to stop.
echo  ===========================================
echo.

:: Keep window open and show server logs
node index.js
